﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MADU_App.ERP
{
    public partial class vendor_form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static IList BindDistrict()
        {
            DataTable Dts = new DataTable();
            MADU_connect2.Service2SoapClient servcon = new MADU_connect2.Service2SoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            Dts = servcon.BindDistrict();
            return JsonConvert.SerializeObject(Dts);
        }

        [WebMethod]
        public static string Bindstate()
        {
            DataTable Dts = new DataTable();
            MADU_connect2.Service2SoapClient servcon = new MADU_connect2.Service2SoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
           
            Dts = servcon.Bindstate();
            return JsonConvert.SerializeObject(Dts);
        }

        [WebMethod]
        public static string Bindpo()
        {
            DataTable Dts = new DataTable();
            MADU_connect2.Service2SoapClient servcon = new MADU_connect2.Service2SoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            Dts = servcon.Bindpo();
            return JsonConvert.SerializeObject(Dts);
        }

        [WebMethod]
        public static string vendor_master(int P_ACTION_ID, int P_VENDOR_NAME, int P_ADDRESS, int P_POST_ID, int P_DISTRICT_ID, int P_STATE_ID, int P_PHONE, string P_EMAIL_ID, int P_GENDER_ID, string P_DOB)

        {
            MADU_connect2.Service2SoapClient servcon = new MADU_connect2.Service2SoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
           
            string Dts = servcon.broadcast_chat_send_msg_grp_db(P_ACTION_ID,P_VENDOR_NAME,P_ADDRESS,P_POST_ID,P_DISTRICT_ID,P_STATE_ID,P_PHONE,P_EMAIL_ID,P_GENDER_ID,P_DOB)
   ;

            return Dts;
        }
    }
}